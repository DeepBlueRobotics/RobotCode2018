#include <unistd.h>
#include <math.h>

#include <memory>

#include "gtest/gtest.h"

#include "frc1678/elevator.h"


namespace frc1678 {
namespace control_loops {
namespace testing {

class ElevatorTest : public ::testing::Test {
 protected:
  ElevatorTest() {}

  // Stall Torque in N m
  static constexpr double kStallTorque = 2.402;
  // Stall Current in Amps
  static constexpr double kStallCurrent = 126.145;
  // Free Speed in RPM
  static constexpr double kFreeSpeed = 5015.562;
  // Free Current in Amps
  static constexpr double kFreeCurrent = 1.170;
  // Mass of the Elevator
  static constexpr double kMass = 20.0;

  // Number of motors
  static constexpr double kNumMotors = 2.0;
  // Resistance of the motor
  static constexpr double kResistance = 12.0 / kStallCurrent;
  // Motor velocity constant
  static constexpr double Kv = ((kFreeSpeed / 60.0 * 2.0 * M_PI) /
             (12.0 - kResistance * kFreeCurrent));
  // Torque constant
  static constexpr double Kt = (kNumMotors * kStallTorque) / kStallCurrent;
  // Gear ratio
  static constexpr double kG = 5;
  // Radius of pulley
  static constexpr double kr = 17 * 0.25 * 0.0254 / M_PI / 2.0;

  // Control loop time step
  static constexpr double kDt = 0.010;

  // V = I * R + omega / Kv
  // torque = Kt * I

  double GetAcceleration(double voltage) {
    return -Kt * kG * kG / (Kv * kResistance * kr * kr * kMass) * velocity_ +
           kG * Kt / (kResistance * kr * kMass) * voltage;
  }

  double position_ = 0.1;
  double velocity_ = 0;
  double voltage_ = 0;
  double offset_ = -0.1;
  double encoder() const { return position_ + offset_; }
  bool halleffect() const { return position_ < 0.0 && position_ > -0.01; }

  double current_time = 0;

  void SimulateTime(double time, double voltage) {
    const double starting_time = time;
    while (time > 0) {
      const double current_dt = ::std::min(time, 0.001);
      position_ += current_dt * velocity_;
      velocity_ += current_dt * GetAcceleration(voltage);
      time -= 0.001;
      EXPECT_LE(position_, ElevatorLoop::kMaxHeight + 0.01);
      EXPECT_GE(position_, ElevatorLoop::kMinHeight - 0.01);
    }
    current_time += starting_time;
  }
};

// Tests that the elevator zeros and goes to a position correctly.
TEST_F(ElevatorTest, Zeros) {
  ElevatorLoop loop;
  loop.set_goal(0.3);
  FILE *f = fopen("/tmp/plot", "w");
  fprintf(f, "# time, voltage, position\n");
  for (int i = 0; i < 500; ++i) {
    const double voltage = loop.Update(encoder(), halleffect(), true);
    if (loop.state() == ElevatorLoop::State::RUNNING) {
      EXPECT_LE(voltage, 12.0);
      EXPECT_GE(voltage, -12.0);
    } else {
      EXPECT_LE(voltage, 4.0);
      EXPECT_GE(voltage, -4.0);
    }
    SimulateTime(kDt, voltage);
    fprintf(f, "%f, %f, %f, %d, %d, %f\n", current_time, voltage, position_,
            halleffect(), static_cast<int>(loop.state()), loop.goal());
  }
  EXPECT_EQ(loop.state(), ElevatorLoop::State::RUNNING);
  EXPECT_NEAR(position_, 0.3, 0.01);
  fclose(f);
}

TEST_F(ElevatorTest, OutOfBounds) {
  ElevatorLoop loop;
  loop.set_goal(10.0);
  FILE *f = fopen("/tmp/plot", "w");
  fprintf(f, "# time, voltage, position\n");
  for (int i = 0; i < 500; ++i) {
    const double voltage = loop.Update(encoder(), halleffect(), true);
    SimulateTime(kDt, voltage);
    fprintf(f, "%f, %f, %f, %d, %d, %f\n", current_time, voltage, position_,
            halleffect(), static_cast<int>(loop.state()), loop.goal());
  }
  EXPECT_EQ(loop.state(), ElevatorLoop::State::RUNNING);
  EXPECT_NEAR(position_, ElevatorLoop::kMaxHeight, 0.01);

  loop.set_goal(-10.0);
  for (int i = 0; i < 500; ++i) {
    const double voltage = loop.Update(encoder(), halleffect(), true);
    SimulateTime(kDt, voltage);
    fprintf(f, "%f, %f, %f, %d, %d, %f\n", current_time, voltage, position_,
            halleffect(), static_cast<int>(loop.state()), loop.goal());
  }
  EXPECT_EQ(loop.state(), ElevatorLoop::State::RUNNING);
  EXPECT_NEAR(position_, ElevatorLoop::kMinHeight, 0.01);
  fclose(f);
}

}  // namespace testing
}  // namespace control_loops
}  // namespace frc1678
