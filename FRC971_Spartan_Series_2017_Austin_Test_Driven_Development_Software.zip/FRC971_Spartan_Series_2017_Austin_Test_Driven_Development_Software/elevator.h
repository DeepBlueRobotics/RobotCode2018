#ifndef FRC1678_ELEVATOR_H_
#define FRC1678_ELEVATOR_H_

namespace frc1678 {
namespace control_loops {

class ElevatorLoop {
 public:

  enum class State {
    DISABLED = 0,
    LOWERING = 1,
    RUNNING = 2,
  };

  // Update needs to be called at 100 hz.
  double Update(double encoder, bool limit_triggered, bool enabled);

  void set_goal(double goal) { goal_ = goal; }

  static constexpr double dt = 0.01;
  // Zeroing velocity in m/sec
  static constexpr double kZeroingVelocity = 0.05;
  // Maximum height.
  static constexpr double kMaxHeight = 0.45;

  // Minimum height.
  static constexpr double kMinHeight = -0.45;
  // Maximum voltage to be applied.
  static constexpr double kMaxVoltage = 12.0;

  State state() const { return state_; }

  double goal() const { return goal_; }
 private:
  State state_ = State::DISABLED;

  double goal_ = 0.0;
  double filtered_goal_ = 0.0;
  // encoder + offset = absolute position
  double offset_ = 0.0;

  double last_error_ = 0;
};

}  // namespace control_loops
}  // namespace frc1678

#endif  // FRC1678_ELEVATOR_H_
