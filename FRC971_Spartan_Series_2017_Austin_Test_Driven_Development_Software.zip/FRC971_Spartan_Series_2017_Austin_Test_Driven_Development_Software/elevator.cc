#include "frc1678/elevator.h"
#include <math.h>
#include <algorithm>

namespace frc1678 {
namespace control_loops {

constexpr double ElevatorLoop::kMaxHeight;
constexpr double ElevatorLoop::kMinHeight;

double ElevatorLoop::Update(double encoder, bool limit_triggered,
                            bool enabled) {
  switch (state_) {
    case State::DISABLED:
      if (enabled) {
        state_ = State::LOWERING;
        filtered_goal_ = encoder;
      }
      break;
    case State::LOWERING:
      if (!enabled) {
        state_ = State::DISABLED;
      } else if (limit_triggered) {
        offset_ = -encoder;
        state_ = State::RUNNING;
      } else {
        filtered_goal_ -= kZeroingVelocity * dt;
      }
      break;
    case State::RUNNING:
      filtered_goal_ = goal_;
      if (filtered_goal_ > kMaxHeight) {
        filtered_goal_ = kMaxHeight;
      } else if (filtered_goal_ < kMinHeight) {
        filtered_goal_ = kMinHeight;
      }
      break;
  }

  constexpr double Kp = 100;
  constexpr double Kd = 1;
  const double error = filtered_goal_ - (encoder + offset_);
  const double voltage = Kp * error + Kd * (error - last_error_) / dt;

  last_error_ = error;
  const double kVoltageLimit = state_ == State::RUNNING ? 12.0 : 4.0;
  return ::std::min(kVoltageLimit, ::std::max(voltage, -kVoltageLimit));
}

}  // namespace control_loops
}  // namespace frc1678
