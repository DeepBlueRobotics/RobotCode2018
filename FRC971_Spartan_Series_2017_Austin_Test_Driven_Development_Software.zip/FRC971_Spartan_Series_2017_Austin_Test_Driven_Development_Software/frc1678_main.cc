#include <Encoder.h>
#include "DriverStation.h"
#include "DigitalInput.h"
#include "Talon.h"
#include "Joystick.h"
#include "frc971/wpilib/wpilib_robot_base.h"
#include <chrono>
#include <thread>

#undef ERROR

#include "aos/linux_code/init.h"
#include "aos/common/util/phased_loop.h"
#include "frc1678/elevator.h"

namespace frc1678 {

class MainRobot : public ::frc971::wpilib::WPILibRobotBase {
 public:
  void Run() override {
    ds = &DriverStation::GetInstance();
    encoder_.reset(new Encoder(1, 2, false, Encoder::k4X));
    hall_effect_.reset(new DigitalInput(0));
    joystick_.reset(new Joystick(2));
    loop_.set_goal(0.3);
    talon1_.reset(new Talon(5));

    // Make this task actually RT.
    ::aos::LockAllMemory();
    ::aos::SetCurrentThreadRealtimePriority(30);

    while (true) {
      while (ds->IsOperatorControl()) {
        // Call IterateLoop every 10ms, 1000 uS off from the start of the clock.
        ::aos::time::PhasedLoopXMS(10, 1000);
        IterateLoop();
      }
    }
  }

  double EncoderPosition() {
    // 17 tooth
    // 25 pitch chain
    // 1:1 reduction from the encoder to the sprocket.
    // 360 cpr, 4x decoding.
    return encoder_->GetRaw() / 360.0 / 4.0 * 17 * 0.25 * 0.0254;
  }

  void IterateLoop() {
    double pwm =
        loop_.Update(EncoderPosition(), !hall_effect_->Get(), ds->IsEnabled()) /
        12.0;

    talon1_->Set(-pwm);
    if (joystick_->GetRawButton(4)) {
      loop_.set_goal(0.2);
    } else if (joystick_->GetRawButton(1)) {
      loop_.set_goal(-0.2);
    }
  }

  ::std::unique_ptr<Encoder> encoder_;
  ::std::unique_ptr<DigitalInput> hall_effect_;
  ::std::unique_ptr<Joystick> joystick_;
  ::std::unique_ptr<Talon> talon1_;

  control_loops::ElevatorLoop loop_;
  DriverStation *ds = nullptr;
};

}  // namespace frc1678

//START_ROBOT_CLASS(frc1678::MainRobot);
AOS_ROBOT_CLASS(frc1678::MainRobot);
